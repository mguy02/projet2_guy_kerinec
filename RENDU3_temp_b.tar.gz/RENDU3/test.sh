#/bin/sh

echo "-------"
echo "Test1.cnf"
./resol tests/test1.cnf
echo ""

echo "Test2.cnf"
./resol tests/test2.cnf
echo ""

echo "Test3.cnf"
./resol tests/test3.cnf
echo ""

echo "Test4.cnf"
./resol tests/test4.cnf
echo ""

echo "Test5.cnf"
./resol tests/test5.cnf
echo ""

echo "Test6.cnf"
./resol tests/test6.cnf
echo ""

echo "Test7.cnf"
./resol tests/test7.cnf
echo ""

echo "Test8.cnf"
./resol tests/test8.cnf
echo ""

echo "---------"
